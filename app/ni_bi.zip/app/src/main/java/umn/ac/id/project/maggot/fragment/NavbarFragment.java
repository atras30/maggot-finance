package umn.ac.id.project.maggot.fragment;

import androidx.fragment.app.Fragment;

import umn.ac.id.project.maggot.R;

public class NavbarFragment extends Fragment {
    public NavbarFragment() {
        super(R.layout.navbar_fragment);
    }
}
