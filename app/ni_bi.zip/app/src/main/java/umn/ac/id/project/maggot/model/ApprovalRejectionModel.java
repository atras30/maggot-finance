package umn.ac.id.project.maggot.model;

public class ApprovalRejectionModel {
    private String message;

    public String approvalUserRegistration() {
        return message;
    }

    public String rejectionUserRegistration() {
        return message;
    }
}
