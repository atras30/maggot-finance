package umn.ac.id.project.maggot.model;

public class BuyMaggotModel {
    private String token;
    private String message;
    private UserModel.User user;
}
