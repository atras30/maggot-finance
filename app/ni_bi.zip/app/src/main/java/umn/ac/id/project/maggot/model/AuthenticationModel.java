package umn.ac.id.project.maggot.model;

import android.util.Log;

import umn.ac.id.project.maggot.model.UserModel;

public class AuthenticationModel {
    private String token;
    private String message;
    private UserModel.User user;

    public Result login() {
        return new Result(token, message, user);
    }

    public String registerUser() {
        return message;
    }

    public class Result {
        private String token;
        private UserModel.User user;
        private String message;

        public String getToken() {
            return token;
        }

        public UserModel.User getUser() {
            return user;
        }

        public String getMessage() {
            return message;
        }

        public Result(String token, String message, UserModel.User user) {
            this.token = token;
            this.message = message;
            this.user = user;
        }

        @Override
        public String toString() {
            return "Result{" +
                    "token='" + token + '\'' +
                    ", user=" + user +
                    ", message='" + message + '\'' +
                    '}';
        }
    }
}
