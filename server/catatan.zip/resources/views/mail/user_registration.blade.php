<p>Halo, {{$createdUser->full_name}}!</p>
<p>Anda telah mengajukan pembuatan akun warga ke pengelola bank sampah {{$createdUser->trash_manager->tempat}}. Mohon untuk menunggu selama 1 sampai 3 hari kerja untuk proses pengajuan ini. Jika proses pengajuan melebihi waktu 3 hari kerja, maka silakan hubungi pengelola bank sampah {{$trashManager->tempat}} di email berikut: {{$trashManager->email}} untuk informasi lebih lanjut.</p>
<p>Terima kasih telah mendaftarkan diri pada aplikasi MagFinance!</p>
<p>Salam hangat,</p>
<p>Tim MagFinance</p>

