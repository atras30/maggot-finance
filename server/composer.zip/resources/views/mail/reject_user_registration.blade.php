Halo, <b>{{ $full_name }}</b>. Aktivasi akun telah di reject oleh pengelola bank sampah.
