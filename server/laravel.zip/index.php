<?php
  redirect("/public");
?>