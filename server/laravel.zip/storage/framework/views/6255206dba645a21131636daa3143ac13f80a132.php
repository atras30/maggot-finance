<table>
    <tbody>
        <tr>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Status</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Deskripsi</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Berat (KG)</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Harga Per KG</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Nama Peternak</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Email Peternak</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Tanggal Transaksi</td>
        </tr>

        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->type); ?></td>
                <td><?php echo e($transaction->description); ?></td>
                <td><?php echo e($transaction->weight_in_kg); ?></td>
                <td><?php echo e($transaction->amount_per_kg); ?></td>
                <td><?php echo e($transaction->farmer->full_name); ?></td>
                <td><?php echo e($transaction->farmer->email); ?></td>
                <td><?php echo e($transaction->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\atras\Documents\Github\maggot-finance\server\resources\views/export/trash_manaer_transaction.blade.php ENDPATH**/ ?>