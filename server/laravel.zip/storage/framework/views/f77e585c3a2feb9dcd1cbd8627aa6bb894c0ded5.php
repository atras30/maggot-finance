<p>Halo, <?php echo e($createdUser->full_name); ?>!</p>
<p>Anda telah mengajukan pembuatan akun warga ke pengelola bank sampah <?php echo e($createdUser->trash_manager->tempat); ?>. Mohon untuk menunggu selama 1 sampai 3 hari kerja untuk proses pengajuan ini. Jika proses pengajuan melebihi waktu 3 hari kerja, maka silakan hubungi pengelola bank sampah <?php echo e($trashManager->tempat); ?> di email berikut: <?php echo e($trashManager->email); ?> untuk informasi lebih lanjut.</p>
<p>Terima kasih telah mendaftarkan diri pada aplikasi MagFinance!</p>
<p>Salam hangat,</p>
<p>Tim MagFinance</p>

<?php /**PATH C:\Users\atras\Documents\Github\maggot-finance\server\resources\views/mail/user_registration.blade.php ENDPATH**/ ?>