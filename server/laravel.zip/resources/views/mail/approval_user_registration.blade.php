Selamat, <b>{{ $full_name }}</b>! Akun anda telah aktif dan bisa melakukan transaksi di dalam aplikasi <b>Maggot Finance</b>, terimakasih telah bergabung di Aplikasi <b>Maggot Finance</b>!
