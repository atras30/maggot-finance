<table>
    <tbody>
        <tr>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Nomor</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Kode</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Deskripsi</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Berat (KG)</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Harga Per KG</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Pengeluaran</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Pemasukan</td>
            <td style="text-align: center; border: 1px solid black; background-color: #EBF1DE; font-weight: bold;">Tanggal Transaksi</td>
        </tr>

        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align:center;"><?php echo e($loop->index + 1); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->type == "expense" ? "Pengeluaran" : "Pemasukan"); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->description); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->weight_in_kg ? $transaction->weight_in_kg : "-"); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->amount_per_kg ? $transaction->amount_per_kg : "-"); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->type == "expense" ? $transaction->total_amount : "-"); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->type == "income" ? $transaction->total_amount : "-"); ?></td>
                <td style="text-align:center;"><?php echo e($transaction->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\atras\Documents\Github\maggot-finance\server\resources\views/export/trash_manaer_transaction.blade.php ENDPATH**/ ?>