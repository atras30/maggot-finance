<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\User;
use Illuminate\Http\Request;

class TransactionController extends Controller {
  public function index(Request $request) {
    $email = $request->email;

    $user = User::where("email", $email)->get()->first();

    if ($user->role == "trash_manager") {
      $transactionHistory = Transaction::where("trash_manager_id", $user->id)->where("transaction_type", "trash_manager_transaction")->where("email", $email)->get();
      return response()->json([
        "data" => $transactionHistory
      ]);
    } else if ($user->role == "farmer") {
      $transactionHistory = Transaction::where("farmer_id", $user->id)->where("transaction_type", "farmer_transaction")->where("email", $email)->get();
      return response()->json([
        "data" => $transactionHistory
      ]);
    }
  }
}
